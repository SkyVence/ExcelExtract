import win32com.client 
from win32com.client import Dispatch
import sys, io
from datetime import date 

# Open up Excel and make it visible
excel = win32com.client.Dispatch('Excel.Application')
excel.Visible = True

# Redirect the stdout to a file
orig_stdout = sys.stdout
bk = io.open("Answers_Report.txt", mode="w", encoding="utf-8")
sys.stdout = bk

# Select a file and open it
file = "C:/Users/antoine.mathie/Documents/PY_Project/data_test.xlsx"
workbook = excel.Workbooks.Open(file)


mission=wb_data.Worksheets("Test1").Range("A1")
vision =wb_data.Worksheets("Test2").Range("B1")


# Wait before closing it
_ = input("Press enter to close Excel")
excel.Quit()